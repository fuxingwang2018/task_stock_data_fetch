from os import path, mkdir
from datetime import datetime
import pandas_datareader.data as web
import quandl
import pandas as pd
import numpy as np
import re

HOME_DIR = path.expanduser("~")


def mkdir_if_not_exist(dir_path):
    if not path.exists(dir_path):
        mkdir(dir_path)


class Provider(object):

    start = "1926-01-01"

    @classmethod
    def from_source(cls, source):
        for sub_cls in cls.__subclasses__():
            sub_cls_source = sub_cls.__name__.split("Provider")[0]
            if source == sub_cls_source.lower():
                return sub_cls()

    def fetch_data(self, ticker, end):
        """Fetch a Pandas Dataframe from Internet"""
        pass


class YahooProvider(Provider):

    source = "yahoo"

    def fetch_data(self, ticker, souece, end):
        return web.DataReader(ticker, self.source, start=self.start, end=end)


class WikiProvider(Provider):

    source = "wiki"

    def fetch_data(self, ticker, source, end):
        return quandl.get(self.source+'/'+ticker, self.source, start_date=self.start, end_date=end, 
		authtoken='ev1XZkFcn2ToynFxeE1L')


class CleanProvider(Provider):

    source = "clean"

    def fetch_data(self, ticker, source, end):

	# DataFrame from different sources: e.g., wiki and yahoo
    	df_yahoo = YahooProvider().fetch_data(ticker, 'yahoo', end)
    	df_wiki = WikiProvider().fetch_data(ticker, 'wiki', end)

	# Merge data from different sources (e.g., wiki and yahoo)
	df_all = pd.concat([df_yahoo,df_wiki], axis=1)

	# Ignore non-space and non-word characters in column names, 
	# then change to lower case to avoid case sensitive
	df_all.columns = df_all.columns.map(lambda x: re.sub(r'[^\s\w]', '', x))
	df_all.columns = df_all.columns.str.lower()

	# Identify duplicated columns
	dup_columns = df_all.columns[df_all.columns.duplicated()]

	# Compute the medium of the common part
	for icol in range(len(dup_columns)):
	    df_all[dup_columns[icol]+'_medium'] = df_all[[dup_columns[icol]]].mean(axis=1)

	# Remove the duplicated original columns and rename the 'medium' columns
	df_clean = df_all.drop(dup_columns, axis=1)
	df_clean.columns = df_clean.columns.str.replace('_medium','')

        return df_clean


class DataReader(object):

    def __init__(self, cache_dir=None):
        self.cache_dir = cache_dir or path.join(HOME_DIR, "stock-data")
        mkdir_if_not_exist(self.cache_dir)

    def read(self, ticker, source="yahoo", end=None):
        end = end or datetime.now().date()
	source_dir = path.join(self.cache_dir, source)
        mkdir_if_not_exist(source_dir)
        filename = path.join(source_dir, ticker + ".csv")
        provider = Provider.from_source(source)
        df = provider.fetch_data(ticker, source, end)
        df.to_csv(filename, header=True)
	print 'Data read successfully for source and ticker:', source, ticker
	print 'They are written to:', filename
        return df


def data_reader(ticker, source="yahoo", end=None):
    return DataReader().read(ticker, source, end)
