from os import path
from shutil import rmtree
from unittest import TestCase
import mock
import pandas as pd
import pandas.util.testing as pdt
import sys
import unittest 

from .. import api

TEST_DIR = path.dirname(__file__)

def _read_time_series_csv(filename):
    return pd.read_csv(filename, parse_dates=True, index_col=0)


def web_reader(ticker, source, *args, **kwargs):
    if source == 'yahoo' or source == 'clean': 
	filename = path.join(TEST_DIR, "mock-stock-data", source, ticker + ".csv")
    elif source == 'wiki': 
	filename = path.join(TEST_DIR, "mock-stock-data", ticker + ".csv")
    else:
	print 'This data source is not ready yet:', source
	sys.exit()
    #print 'filename:',filename
    return _read_time_series_csv(filename)


@mock.patch(api.__name__ + ".mkdir")
def test_mkdir_if_not_exist(m_mkdir):
    dir_path = path.join(TEST_DIR, "dummy")
    api.mkdir_if_not_exist(dir_path)
    m_mkdir.assert_called_with(dir_path)


class DataReaderTest(TestCase):
    stock_data_dir = path.join(TEST_DIR, "stock-data")

    def setUp(self):
        api.HOME_DIR = TEST_DIR
        patcher1 = mock.patch(api.__name__ + ".web.DataReader",
                              side_effect=web_reader)
        patcher2 = mock.patch(api.__name__ + ".quandl.get",
                              side_effect=web_reader)
        self.m_web_reader1 = patcher1.start()
        self.m_web_reader2 = patcher2.start()
        self.addCleanup(patcher1.stop)
        self.addCleanup(patcher2.stop)
        self.reader = api.DataReader()

    def test_cache_dir(self):
        self.assertEqual(self.reader.cache_dir, self.stock_data_dir)

    def test_data_reader(self):
        ticker = "GOOG"
        end = "2017-11-03"

	# yahoo
        df = api.data_reader(ticker, source='yahoo', end=end)
        self.m_web_reader1.assert_called_with(
            ticker, "yahoo", start="1926-01-01", end=end
        )
        expected = web_reader(ticker, 'yahoo')
        pdt.assert_frame_equal(df, expected)
	print 'test_data_reader_yahoo:done'

	# wiki
        df = api.data_reader(ticker, source='wiki', end=end)
        self.m_web_reader2.assert_called_with(
            "wiki/"+ticker, 'wiki', start_date="1926-01-01", end_date=end, authtoken='ev1XZkFcn2ToynFxeE1L',
        )
        expected = web_reader("wiki/"+ticker, 'wiki')
        pdt.assert_frame_equal(df, expected)
	print 'test_data_reader_wiki:done'

	# clean
        df = api.data_reader(ticker, source='clean', end=end)

	print 'test_data_reader:done'

    def runTest(self):
	pass

    @classmethod
    def tearDownClass(cls):
        pass #rmtree(cls.stock_data_dir)


if __name__ == "__main__":
    suite = unittest.TestSuite()
    suite.addTest(DataReaderTest("test_data_reader"))
    runner = unittest.TextTestRunner()
    runner.run(suite)
